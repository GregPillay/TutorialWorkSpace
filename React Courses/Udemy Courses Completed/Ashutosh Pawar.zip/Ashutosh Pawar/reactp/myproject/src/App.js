 
import './App.css';
import Hello from './components/Hello'; 
// import Hello ( Hello is the name of the imported functional component). The file path needs to be specified.
import Message from './components/Message';
// import Message ( Message is the name of the imported Class component).
import Hello2 from './jsx/jsxHello';
// import Hello2 ( Hello2 is the name of the imported functional component that contains jsx).
import Profile from './components/Profile';
// import profile ( profile is the name of the imported functional component that is used to demostrate props.).
import NewProfile from './components/NewProfile';

import Counter from './components/Counter';
import Greeting from './components/Greeting';
import Resume from './components/Resume';

import FunctEvent from './components/FunctionEvent';
import ClassEvent from './components/ClassEvent';
/*  // Demostration of components
function App() {
  return (
    <div className="App">
 
      <Hello></Hello>    
      <Message></Message>
      <Hello2/>
    </div>
  );
}
// to call the component Hello, use HTML Tags -->  <Hello> </Hello>
*/
// ________________________________________________________________________________________________

/*

   //demostration of props

    function App() 
    {
      return (
         <div className="App">
  
           <Profile name = "Greg"/>

           <NewProfile message = "This is a message prop."/> 
           </div>
  );
}

//to pass a property , specify in the html tags for the Profile file.
*/

// _________________________________________________________________________________________________

//demostration of the State statement in class and functional base components.
function App() 
{
  return (
     <div className="App">
 <Counter/>

 <Greeting message ="Welcome Mr "name = "Greg!" />
 <Resume title = "Software Engineer."/>
 <br></br>
 <FunctEvent/>
 <br></br>
 <ClassEvent/>
       </div>
       
        );
}

export default App;
