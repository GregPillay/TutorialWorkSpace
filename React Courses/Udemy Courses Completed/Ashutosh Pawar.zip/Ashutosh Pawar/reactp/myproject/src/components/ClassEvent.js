// class based component created to demonstrate the Event Handler.

import { Component } from "react";

class ClassEvent extends Component
{
    handleClick()                                                    // a method created instead of a function.
      {
           console.log("Button Clicked!");
      };

    render()
     {
        return <div> 
            Class based Event : <br></br>
            <button onClick = {this.handleClick}>Click Here!</button>  
               </div>
     };                                                                 //use this to call the method.
}
export default ClassEvent;