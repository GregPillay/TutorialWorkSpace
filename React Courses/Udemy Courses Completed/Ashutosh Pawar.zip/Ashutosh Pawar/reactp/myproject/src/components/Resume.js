// Class based component created to demostrate the deconstruction of props.

import { Component } from "react";

class Resume extends Component 
  {
    render()
     {
        const {title} = this.props;         // same process as the functional component but use this.props
       return  <h4>Job Title : {title}</h4>
     };
  };

 export default Resume;