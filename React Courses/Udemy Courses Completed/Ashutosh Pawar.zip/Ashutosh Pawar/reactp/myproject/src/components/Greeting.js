// Greeting.js is created as a functional prop component that demostrates the 
//deconstruction of the prop object.

function Greeting(props)
 {
   // return <h2>{props.message} {props.name}</h2>  // using props

   const   {message , name} = props;  // a const is created with params and equalled to props
 
    return <h2>{message} {name}</h2>   // therefore doesnt require the prop.
 };

export default Greeting;