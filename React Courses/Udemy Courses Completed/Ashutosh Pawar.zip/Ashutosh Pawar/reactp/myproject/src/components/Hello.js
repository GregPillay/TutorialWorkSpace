// Functional Component
/*  // Using jS format.
function Hello()                      //Function Called Hello 
{                                    // Hello component to be called in the main interface (App.js).
    return <h1>Hello World!.</h1>   //HTML Element returned.
};

export default Hello; 

 // Export means the file can be exported and imported elsewhere.
 

// to nest the Hello Component into App.js, it needs to be exported and imported into the App.js.
/* STeps : After Declaring the Hello function, type --> export default Hello; */
  // (1) Create the function in .js format
  // (2) use the export command to export the file.
  // (3) In the App.js [Main File], import the component file and specify file path.
  // (4) Call the component file within the App Method.

//using ES6 syntax for the function
 const Hello = () => <h1>Hello There!</h1>

export default Hello; 

 // Export means the file can be exported and imported elsewhere.