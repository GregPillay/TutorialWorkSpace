// Counter.js created to demostrate the state statement in a class based component.
// Displays a count variable and changes the value.

import { Component } from "react";

class Counter extends Component
{
    constructor()
    {
        super();
        this.state = 
          {
            counter : 0,
          };
    }

    increment ()
    {
        this.setState
        (
            {
                counter : this.state.counter + 1 ,       //method/event created to manipulate the counter
            }
        );
    };
// for the button, use the React Event Handler 'onClick' and parse a method/event for the button (increment).
 render()
  {

    return (<div> 
        <h3>Count value is : {this.state.counter} <p></p>
        <button onClick={()=> this.increment()}> Increment</button>  
        </h3>
           </div>
          )
  };
};
// to hold the counter value, use a state object by creating a constructor.
// contructor is used to instialise certain values. Super Method is called because it calls the base-class [Component].

// A button will be created to increment the value of the counter.
//since the button element cant be added becoz the return object only returns 1 html element and 
//we have 2 (<h3> & <button>), we can create a <div> tag and return that element.

// Event Handling of the button.
export default Counter;