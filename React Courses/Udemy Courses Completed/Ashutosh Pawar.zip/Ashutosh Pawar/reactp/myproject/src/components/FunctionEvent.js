// functional based component created to demonstrate the Event Handler.

function FunctEvent()
{   function handleClick()
     {
       console.log ("Button Clicked!");
     }
   
   return <div>
    Functional based Component : <br></br>
        <button onClick={ handleClick}>Click Here!</button>
           </div>
};

export default FunctEvent;

// Event : onClick
// event must be equal to a function in curly braces { }.
// Function created is handleClick. Done use the ( ) in the event 
// because it will run although the button hasnt been clicked.