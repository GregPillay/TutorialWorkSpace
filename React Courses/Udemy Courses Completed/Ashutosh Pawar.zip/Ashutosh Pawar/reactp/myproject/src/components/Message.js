//  Class Component
// to convert the ES6 class into React, you will have to use extends 
// Extends -> It inherits from the component class of react Library.
// when we inherit, we need to import the react files for component

import {Component} from "react";

class Message extends Component
{
 render()
  {
     return <h1>This is a class component</h1>
  }
}
// return an HTML Element.
export default Message;