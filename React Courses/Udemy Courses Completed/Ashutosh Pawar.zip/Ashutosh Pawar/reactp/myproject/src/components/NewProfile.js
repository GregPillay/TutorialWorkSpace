//  Class Component used to demostrat the props functionality
 

import {Component} from "react";

class NewProfile extends Component
{
 render()
  {
     return <h1>Example : {this.props.message}</h1>
  }
}
 
export default NewProfile;