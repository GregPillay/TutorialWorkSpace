// component created to demostrate the operations of a prop.

// props is used to pass a value.
// in this example , we gona pass the name variable. 
// we can specify the name prop in the App.js file and pass the name. ==> GoTo App.js

// inorder to show the props, you need to select which props property you want to parse.
function profile (props)
{ 
    console.log(props);
    return <h1>My name is {props.name}!</h1>}

export default profile;