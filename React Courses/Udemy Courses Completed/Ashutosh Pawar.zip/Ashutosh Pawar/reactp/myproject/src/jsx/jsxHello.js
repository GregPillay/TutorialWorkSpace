// using the jsx method, parse a Javascript variable [name] into html element:
/*
const name = "Gregory";     // js variable thats passed
function Hello2()          // functional component
{
    return <h1>Hello {name}</h1>
}
*/

//passing a js function
const displaymsg = ()=>
{
    return "I am hungry!";
}

function Hello2()          // functional component
{
    return <h1>Display message is  {displaymsg()}</h1>
}
// to call the method, the () needs to be included.
export default Hello2;